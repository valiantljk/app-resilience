#!/bin/sh

./parse_castro_params.py -m Src_nd/meth_params.template ./_cpp_parameters
